package hu.bme.aut.vanrent.data;

public class TimeSlot {

    public int startHour;
    public int endHour;

    public TimeSlot(int start, int end){
        startHour = start;
        endHour = end;
    }

}
